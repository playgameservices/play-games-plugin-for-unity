var class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome =
[
    [ "ParticipantResult", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html#add364f70ac5c2d7ecffc5a261d548442", [
      [ "Unset", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html#add364f70ac5c2d7ecffc5a261d548442ac9f88e098f6fe4e4e112eeb05ccb9671", null ],
      [ "None", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html#add364f70ac5c2d7ecffc5a261d548442a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Win", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html#add364f70ac5c2d7ecffc5a261d548442a119eac47719cc9be7b99124712e229da", null ],
      [ "Loss", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html#add364f70ac5c2d7ecffc5a261d548442a14781ee5e859104d453ad3eb28b441e5", null ],
      [ "Tie", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html#add364f70ac5c2d7ecffc5a261d548442a2de86fa016c5a004fb0b0e8b707ea99b", null ]
    ] ],
    [ "MatchOutcome", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html#a01b68472ba23c0a6a98bb5da1d3243ef", null ],
    [ "GetPlacementFor", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html#a48d0d8945add17bf4aaba4b95eb922f8", null ],
    [ "GetResultFor", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html#a14ed6fda9d0d1c9ecc82c7f90c9f73c9", null ],
    [ "SetParticipantResult", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html#aa6e59257d77cc531e7fd8ddffdf3e2ad", null ],
    [ "SetParticipantResult", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html#a712cefb81b4b01d3efd9ab68782e93b4", null ],
    [ "SetParticipantResult", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html#a62ca7585c0d8cb8861b1e76b17b0f478", null ],
    [ "ToString", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html#abf4498d08e8c0a75c48e737dfb4657a1", null ],
    [ "PlacementUnset", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html#a9e3b9b1aab003cc08eb7236b2bff9bf8", null ],
    [ "ParticipantIds", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html#ab4be6fc9d8a0d5aa0e05bb538c980b99", null ]
];