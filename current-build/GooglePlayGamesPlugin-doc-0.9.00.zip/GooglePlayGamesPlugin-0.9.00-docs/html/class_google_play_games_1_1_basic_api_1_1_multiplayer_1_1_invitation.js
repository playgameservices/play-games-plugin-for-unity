var class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_invitation =
[
    [ "InvType", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_invitation.html#a7f429d484a39d1093dd18f925f454e64", [
      [ "RealTime", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_invitation.html#a7f429d484a39d1093dd18f925f454e64ad50ae798e3aa50c3a502118e759cc216", null ],
      [ "TurnBased", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_invitation.html#a7f429d484a39d1093dd18f925f454e64a1eff85ba5a6fb257c91e0f1effd2f258", null ],
      [ "Unknown", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_invitation.html#a7f429d484a39d1093dd18f925f454e64a88183b946cc5f0e8c96b2e66e1c74a7e", null ]
    ] ],
    [ "ToString", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_invitation.html#a5dd419e787fb50b30f1b0b55621d46e3", null ],
    [ "InvitationId", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_invitation.html#a2a7195ba1aa0a462cfcbe8446f451533", null ],
    [ "InvitationType", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_invitation.html#a7cb9c87947e5b49af64225a8a155a920", null ],
    [ "Inviter", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_invitation.html#a95f833b70929c23372a538248e23387f", null ],
    [ "Variant", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_invitation.html#ad1acda7e546b13e49032643d958718a4", null ]
];