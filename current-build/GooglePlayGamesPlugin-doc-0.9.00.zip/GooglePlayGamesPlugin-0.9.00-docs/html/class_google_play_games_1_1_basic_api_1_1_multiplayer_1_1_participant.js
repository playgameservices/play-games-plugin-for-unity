var class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant =
[
    [ "ParticipantStatus", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#a649c5ea3516d46bb41aace3ef33c06c3", [
      [ "NotInvitedYet", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#a649c5ea3516d46bb41aace3ef33c06c3acd5a7c8bdf0bfbf376e586291cbe67b1", null ],
      [ "Invited", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#a649c5ea3516d46bb41aace3ef33c06c3aaa3443ffdec7410e60018515486e1279", null ],
      [ "Joined", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#a649c5ea3516d46bb41aace3ef33c06c3a7d50c09f1ad7d098e0a847bcdcab7efb", null ],
      [ "Declined", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#a649c5ea3516d46bb41aace3ef33c06c3a616b5940be86c327aaa5090f50c061f5", null ],
      [ "Left", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#a649c5ea3516d46bb41aace3ef33c06c3a945d5e233cf7d6240f6b783b36a374ff", null ],
      [ "Finished", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#a649c5ea3516d46bb41aace3ef33c06c3a8f3d10eb21bd36347c258679eba9e92b", null ],
      [ "Unresponsive", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#a649c5ea3516d46bb41aace3ef33c06c3a752300eb612452a182d741fa70ab86ef", null ],
      [ "Unknown", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#a649c5ea3516d46bb41aace3ef33c06c3a88183b946cc5f0e8c96b2e66e1c74a7e", null ]
    ] ],
    [ "CompareTo", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#a18db5114efa3457755e776f851133d59", null ],
    [ "Equals", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#a4dfa71b0373f0f5da859b40657ea25fb", null ],
    [ "GetHashCode", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#a912220385bf5c46c1aac1cc40d6c710c", null ],
    [ "ToString", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#af5d0f65cfbab4a4c5031f081f7439c16", null ],
    [ "DisplayName", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#a704a5e44ed0ef291d3af5ec3d46a0838", null ],
    [ "IsAutomatch", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#ac4b2b8f6df174c3580a87d08fbcbf749", null ],
    [ "IsConnectedToRoom", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#a9a6715fefd85248d8df9044e83769094", null ],
    [ "ParticipantId", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#a8bec258819de5ecfcbc84bb2693c9692", null ],
    [ "Player", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#a4778cc36def93f65ce4d5801a0c2d679", null ],
    [ "Status", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#ae8aa22d36e3bb2c625a805f828c4f509", null ]
];