var class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_player =
[
    [ "Equals", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_player.html#aff2d4e88759a586d306e157cf0dd9053", null ],
    [ "GetHashCode", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_player.html#ae770f23e50f06158bd3777ee5a54d8ad", null ],
    [ "ToString", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_player.html#ab3a2ce537a00d1583698bb2f17ff2c51", null ],
    [ "DisplayName", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_player.html#a5330a8eff2eccae1f805fa011951f8d1", null ],
    [ "PlayerId", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_player.html#a4381c5e19effcd0e2681a5f5c77fff12", null ]
];