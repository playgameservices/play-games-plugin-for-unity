var searchData=
[
  ['finish',['Finish',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#a6fed0b76e96a2a56aaae1dba6cbcdf0d',1,'GooglePlayGames::BasicApi::Multiplayer::ITurnBasedMultiplayerClient']]]
];
