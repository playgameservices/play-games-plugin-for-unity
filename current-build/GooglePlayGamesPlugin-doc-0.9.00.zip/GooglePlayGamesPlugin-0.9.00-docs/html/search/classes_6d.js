var searchData=
[
  ['matchoutcome',['MatchOutcome',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html',1,'GooglePlayGames::BasicApi::Multiplayer']]]
];
