var searchData=
[
  ['cancel',['Cancel',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#a6f749989a1e3c7467e79e3e3b23799dd',1,'GooglePlayGames::BasicApi::Multiplayer::ITurnBasedMultiplayerClient']]],
  ['createachievement',['CreateAchievement',['../class_google_play_games_1_1_play_games_platform.html#a5a3c8132294dfa17c965377292ef3131',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['createleaderboard',['CreateLeaderboard',['../class_google_play_games_1_1_play_games_platform.html#a3f61a6cd7ed0864955972c76d346180d',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['createquickgame',['CreateQuickGame',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#abe2c254dda191a9a65d53006a6927b4f',1,'GooglePlayGames::BasicApi::Multiplayer::IRealTimeMultiplayerClient']]],
  ['createquickmatch',['CreateQuickMatch',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#a8321bf0898ac432f8db286f4681a79f2',1,'GooglePlayGames::BasicApi::Multiplayer::ITurnBasedMultiplayerClient']]],
  ['createwithinvitationscreen',['CreateWithInvitationScreen',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#ab59ad2e99f6b63b4cf71ad3bc9b0fb48',1,'GooglePlayGames.BasicApi.Multiplayer.IRealTimeMultiplayerClient.CreateWithInvitationScreen()'],['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#ad2b3a4a0082ff9d39de0b9d9bab1e568',1,'GooglePlayGames.BasicApi.Multiplayer.ITurnBasedMultiplayerClient.CreateWithInvitationScreen()']]]
];
