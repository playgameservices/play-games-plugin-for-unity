var searchData=
[
  ['updatestate',['UpdateState',['../class_google_play_games_1_1_play_games_platform.html#acfb3a2aa7a5a3b345211852d7cc53ec7',1,'GooglePlayGames::PlayGamesPlatform']]]
];
