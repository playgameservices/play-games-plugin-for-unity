var searchData=
[
  ['data',['Data',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#ac49d79cbb58afd404bbc6d21cb9ce267',1,'GooglePlayGames::BasicApi::Multiplayer::TurnBasedMatch']]],
  ['date',['date',['../class_google_play_games_1_1_play_games_score.html#af911623bfd163f919819beac7610e01a',1,'GooglePlayGames::PlayGamesScore']]],
  ['debuglogenabled',['DebugLogEnabled',['../class_google_play_games_1_1_play_games_platform.html#a850e7ad93813230a847878b7e1d2de5c',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['displayname',['DisplayName',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#a704a5e44ed0ef291d3af5ec3d46a0838',1,'GooglePlayGames.BasicApi.Multiplayer.Participant.DisplayName()'],['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_player.html#a5330a8eff2eccae1f805fa011951f8d1',1,'GooglePlayGames.BasicApi.Multiplayer.Player.DisplayName()']]]
];
