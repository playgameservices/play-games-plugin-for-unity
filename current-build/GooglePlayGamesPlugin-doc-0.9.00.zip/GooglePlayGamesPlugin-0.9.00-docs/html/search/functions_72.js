var searchData=
[
  ['registerinvitationdelegate',['RegisterInvitationDelegate',['../class_google_play_games_1_1_play_games_platform.html#a90a767a3aa3dc58661aaef99468a460f',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['registermatchdelegate',['RegisterMatchDelegate',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#a4ef9a326e9833136027302d3fc4d0a7a',1,'GooglePlayGames::BasicApi::Multiplayer::ITurnBasedMultiplayerClient']]],
  ['rematch',['Rematch',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#acea95d30ef8ce82b4c4762e0a3e979fc',1,'GooglePlayGames::BasicApi::Multiplayer::ITurnBasedMultiplayerClient']]],
  ['reportprogress',['ReportProgress',['../class_google_play_games_1_1_play_games_achievement.html#a3006dd50e1b56909041266b071ffc723',1,'GooglePlayGames.PlayGamesAchievement.ReportProgress()'],['../class_google_play_games_1_1_play_games_platform.html#a64dff72e31b512bdd15169c08852fb6d',1,'GooglePlayGames.PlayGamesPlatform.ReportProgress()']]],
  ['reportscore',['ReportScore',['../class_google_play_games_1_1_play_games_platform.html#a9a51e50e3de344ec7c896d89ca600b1d',1,'GooglePlayGames.PlayGamesPlatform.ReportScore()'],['../class_google_play_games_1_1_play_games_score.html#a2848d7c555e8e78bcf7de42b2b255560',1,'GooglePlayGames.PlayGamesScore.ReportScore()']]]
];
