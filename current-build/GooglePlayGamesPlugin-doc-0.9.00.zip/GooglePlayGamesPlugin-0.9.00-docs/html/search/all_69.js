var searchData=
[
  ['id',['id',['../class_google_play_games_1_1_play_games_achievement.html#a5fb2ae47d11f215d58ec88b52b0a6803',1,'GooglePlayGames.PlayGamesAchievement.id()'],['../class_google_play_games_1_1_play_games_local_user.html#abccc69bf41e6181740dcf8b26a92b291',1,'GooglePlayGames.PlayGamesLocalUser.id()']]],
  ['incrementachievement',['IncrementAchievement',['../class_google_play_games_1_1_play_games_platform.html#a00118ca719d9b61a9e62154ca9a99899',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['instance',['Instance',['../class_google_play_games_1_1_play_games_platform.html#a4895a06cafea42728ff73cb0435c136e',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['invitation',['Invitation',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_invitation.html',1,'GooglePlayGames::BasicApi::Multiplayer']]],
  ['invitationid',['InvitationId',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_invitation.html#a2a7195ba1aa0a462cfcbe8446f451533',1,'GooglePlayGames::BasicApi::Multiplayer::Invitation']]],
  ['invitationtype',['InvitationType',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_invitation.html#a7cb9c87947e5b49af64225a8a155a920',1,'GooglePlayGames::BasicApi::Multiplayer::Invitation']]],
  ['inviter',['Inviter',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_invitation.html#a95f833b70929c23372a538248e23387f',1,'GooglePlayGames::BasicApi::Multiplayer::Invitation']]],
  ['irealtimemultiplayerclient',['IRealTimeMultiplayerClient',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html',1,'GooglePlayGames::BasicApi::Multiplayer']]],
  ['isauthenticated',['IsAuthenticated',['../class_google_play_games_1_1_play_games_platform.html#ae1ba863528f49f91e63a6ca9d7428765',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['isautomatch',['IsAutomatch',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#ac4b2b8f6df174c3580a87d08fbcbf749',1,'GooglePlayGames::BasicApi::Multiplayer::Participant']]],
  ['isconnectedtoroom',['IsConnectedToRoom',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#a9a6715fefd85248d8df9044e83769094',1,'GooglePlayGames::BasicApi::Multiplayer::Participant']]],
  ['isfriend',['isFriend',['../class_google_play_games_1_1_play_games_local_user.html#aeaeb7d54b3b73451961ba9b8aaf72737',1,'GooglePlayGames::PlayGamesLocalUser']]],
  ['isroomconnected',['IsRoomConnected',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#ade8f785677c1dd00f7535d223ad21445',1,'GooglePlayGames::BasicApi::Multiplayer::IRealTimeMultiplayerClient']]],
  ['iturnbasedmultiplayerclient',['ITurnBasedMultiplayerClient',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html',1,'GooglePlayGames::BasicApi::Multiplayer']]]
];
