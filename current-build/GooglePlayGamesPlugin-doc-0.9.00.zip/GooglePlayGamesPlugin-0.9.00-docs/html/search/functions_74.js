var searchData=
[
  ['taketurn',['TakeTurn',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#a2040384a537d7900fb2114f72ac503b8',1,'GooglePlayGames::BasicApi::Multiplayer::ITurnBasedMultiplayerClient']]]
];
