var searchData=
[
  ['onleftroom',['OnLeftRoom',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_real_time_multiplayer_listener.html#af43ccbb1bc50bbfa465d25c99192d4a9',1,'GooglePlayGames::BasicApi::Multiplayer::RealTimeMultiplayerListener']]],
  ['onpeersconnected',['OnPeersConnected',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_real_time_multiplayer_listener.html#a348876946690c196ca4be7cfb900ef58',1,'GooglePlayGames::BasicApi::Multiplayer::RealTimeMultiplayerListener']]],
  ['onpeersdisconnected',['OnPeersDisconnected',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_real_time_multiplayer_listener.html#a2b231346f426234259f2f0bb4de631bd',1,'GooglePlayGames::BasicApi::Multiplayer::RealTimeMultiplayerListener']]],
  ['onrealtimemessagereceived',['OnRealTimeMessageReceived',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_real_time_multiplayer_listener.html#a8424d52163cbf567689ea1dddb424de8',1,'GooglePlayGames::BasicApi::Multiplayer::RealTimeMultiplayerListener']]],
  ['onroomconnected',['OnRoomConnected',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_real_time_multiplayer_listener.html#aab6b8ada46722291ade15cadd24e9ad5',1,'GooglePlayGames::BasicApi::Multiplayer::RealTimeMultiplayerListener']]],
  ['onroomsetupprogress',['OnRoomSetupProgress',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_real_time_multiplayer_listener.html#af24eda5f76dbb59c272dca71f9f9d4c7',1,'GooglePlayGames::BasicApi::Multiplayer::RealTimeMultiplayerListener']]]
];
