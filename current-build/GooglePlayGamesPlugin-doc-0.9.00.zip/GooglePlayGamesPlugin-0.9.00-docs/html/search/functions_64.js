var searchData=
[
  ['declineinvitation',['DeclineInvitation',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#a21c22f516d6644626228541d85ac11fa',1,'GooglePlayGames.BasicApi.Multiplayer.IRealTimeMultiplayerClient.DeclineInvitation()'],['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#a511964a8459b8a13f91d49da3e759a2e',1,'GooglePlayGames.BasicApi.Multiplayer.ITurnBasedMultiplayerClient.DeclineInvitation()']]]
];
