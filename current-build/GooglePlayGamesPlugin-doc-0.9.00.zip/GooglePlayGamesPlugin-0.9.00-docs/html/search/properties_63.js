var searchData=
[
  ['canrematch',['CanRematch',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#a63887909bea098a58616875680eac6d7',1,'GooglePlayGames::BasicApi::Multiplayer::TurnBasedMatch']]],
  ['completed',['completed',['../class_google_play_games_1_1_play_games_achievement.html#a05bc52e509656cd0d5cb66248e3979e2',1,'GooglePlayGames::PlayGamesAchievement']]]
];
