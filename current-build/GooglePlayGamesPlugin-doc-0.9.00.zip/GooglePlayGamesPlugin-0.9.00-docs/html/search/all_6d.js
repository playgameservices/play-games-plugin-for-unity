var searchData=
[
  ['matchdelegate',['MatchDelegate',['../namespace_google_play_games_1_1_basic_api_1_1_multiplayer.html#ae4e526af1d9629020403818634f0dce2',1,'GooglePlayGames::BasicApi::Multiplayer']]],
  ['matchid',['MatchId',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#ad0e5262ef576a201883e8802f74a1675',1,'GooglePlayGames::BasicApi::Multiplayer::TurnBasedMatch']]],
  ['matchoutcome',['MatchOutcome',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html',1,'GooglePlayGames::BasicApi::Multiplayer']]]
];
