var searchData=
[
  ['basicapi',['BasicApi',['../namespace_google_play_games_1_1_basic_api.html',1,'GooglePlayGames']]],
  ['getconnectedparticipants',['GetConnectedParticipants',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#a022de50b648aab1c483411ff06e96a6d',1,'GooglePlayGames::BasicApi::Multiplayer::IRealTimeMultiplayerClient']]],
  ['getloading',['GetLoading',['../class_google_play_games_1_1_play_games_platform.html#a9555dc92333723ab50047f37687919f6',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['getmaxmatchdatasize',['GetMaxMatchDataSize',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#af0a03ebffc917ccf350d8d962701b7de',1,'GooglePlayGames::BasicApi::Multiplayer::ITurnBasedMultiplayerClient']]],
  ['getparticipant',['GetParticipant',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#afd2c2ce2040c764a3370f00789086d89',1,'GooglePlayGames.BasicApi.Multiplayer.IRealTimeMultiplayerClient.GetParticipant()'],['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#ad92ba68d31cb4d61e0ad08c86da339a3',1,'GooglePlayGames.BasicApi.Multiplayer.TurnBasedMatch.GetParticipant()']]],
  ['getplacementfor',['GetPlacementFor',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html#a48d0d8945add17bf4aaba4b95eb922f8',1,'GooglePlayGames::BasicApi::Multiplayer::MatchOutcome']]],
  ['getresultfor',['GetResultFor',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html#a14ed6fda9d0d1c9ecc82c7f90c9f73c9',1,'GooglePlayGames::BasicApi::Multiplayer::MatchOutcome']]],
  ['getself',['GetSelf',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#a1977bfbd33895593167aa562c021053b',1,'GooglePlayGames::BasicApi::Multiplayer::IRealTimeMultiplayerClient']]],
  ['getuserdisplayname',['GetUserDisplayName',['../class_google_play_games_1_1_play_games_platform.html#ad33a89088ff06798207be4a1f808dc6c',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['getuserid',['GetUserId',['../class_google_play_games_1_1_play_games_platform.html#ad2c68f0709dd3e2201e42ffa195b25b3',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['googleplaygames',['GooglePlayGames',['../namespace_google_play_games.html',1,'']]],
  ['getting_20started',['Getting Started',['../index.html',1,'']]],
  ['multiplayer',['Multiplayer',['../namespace_google_play_games_1_1_basic_api_1_1_multiplayer.html',1,'GooglePlayGames::BasicApi']]]
];
