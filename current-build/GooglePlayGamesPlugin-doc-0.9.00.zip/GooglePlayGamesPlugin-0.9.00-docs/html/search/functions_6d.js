var searchData=
[
  ['matchdelegate',['MatchDelegate',['../namespace_google_play_games_1_1_basic_api_1_1_multiplayer.html#ae4e526af1d9629020403818634f0dce2',1,'GooglePlayGames::BasicApi::Multiplayer']]]
];
