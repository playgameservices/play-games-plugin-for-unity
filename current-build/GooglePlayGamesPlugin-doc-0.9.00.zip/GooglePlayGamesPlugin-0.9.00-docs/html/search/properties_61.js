var searchData=
[
  ['authenticated',['authenticated',['../class_google_play_games_1_1_play_games_local_user.html#ab8f1d6fbe6b60c79b500fb41f1839653',1,'GooglePlayGames::PlayGamesLocalUser']]]
];
