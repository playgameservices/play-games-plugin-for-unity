var searchData=
[
  ['turnbased',['TurnBased',['../class_google_play_games_1_1_play_games_platform.html#a78086fcb0fca503e4994cfbeeae6c383',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['turnstatus',['TurnStatus',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#a1b544ef1ac4977a1cb57617abfdacd78',1,'GooglePlayGames::BasicApi::Multiplayer::TurnBasedMatch']]]
];
