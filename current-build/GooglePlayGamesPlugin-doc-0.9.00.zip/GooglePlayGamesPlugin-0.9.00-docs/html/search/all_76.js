var searchData=
[
  ['value',['value',['../class_google_play_games_1_1_play_games_score.html#a1044600e530e02458627df717528c107',1,'GooglePlayGames::PlayGamesScore']]],
  ['variant',['Variant',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_invitation.html#ad1acda7e546b13e49032643d958718a4',1,'GooglePlayGames.BasicApi.Multiplayer.Invitation.Variant()'],['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#a173286af471b1ae7fcde2c6c3cf28ce1',1,'GooglePlayGames.BasicApi.Multiplayer.TurnBasedMatch.Variant()']]]
];
