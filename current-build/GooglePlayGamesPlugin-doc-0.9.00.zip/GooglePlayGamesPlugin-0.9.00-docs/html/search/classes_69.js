var searchData=
[
  ['invitation',['Invitation',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_invitation.html',1,'GooglePlayGames::BasicApi::Multiplayer']]],
  ['irealtimemultiplayerclient',['IRealTimeMultiplayerClient',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html',1,'GooglePlayGames::BasicApi::Multiplayer']]],
  ['iturnbasedmultiplayerclient',['ITurnBasedMultiplayerClient',['../interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html',1,'GooglePlayGames::BasicApi::Multiplayer']]]
];
