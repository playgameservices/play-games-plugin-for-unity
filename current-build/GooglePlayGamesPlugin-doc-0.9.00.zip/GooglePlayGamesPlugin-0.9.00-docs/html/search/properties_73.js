var searchData=
[
  ['self',['Self',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#a96c605333ea2407bb7f2415c7be0e282',1,'GooglePlayGames::BasicApi::Multiplayer::TurnBasedMatch']]],
  ['selfparticipantid',['SelfParticipantId',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#ab93685c005a7c40c087f7d2b7cba7d7f',1,'GooglePlayGames::BasicApi::Multiplayer::TurnBasedMatch']]],
  ['state',['state',['../class_google_play_games_1_1_play_games_local_user.html#a3aee9494d5963d525f461f461302123d',1,'GooglePlayGames::PlayGamesLocalUser']]],
  ['status',['Status',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html#ae8aa22d36e3bb2c625a805f828c4f509',1,'GooglePlayGames.BasicApi.Multiplayer.Participant.Status()'],['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#a44dd823209e05050a08d0f6950f2471e',1,'GooglePlayGames.BasicApi.Multiplayer.TurnBasedMatch.Status()']]]
];
