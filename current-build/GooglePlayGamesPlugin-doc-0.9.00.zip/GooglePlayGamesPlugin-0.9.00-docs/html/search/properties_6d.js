var searchData=
[
  ['matchid',['MatchId',['../class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#ad0e5262ef576a201883e8802f74a1675',1,'GooglePlayGames::BasicApi::Multiplayer::TurnBasedMatch']]]
];
