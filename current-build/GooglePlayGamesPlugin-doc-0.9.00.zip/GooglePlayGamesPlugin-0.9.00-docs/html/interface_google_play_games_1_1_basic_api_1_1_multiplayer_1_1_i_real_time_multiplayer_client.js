var interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client =
[
    [ "AcceptFromInbox", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#ae5e87b26738ddea416bb2832313521a1", null ],
    [ "AcceptInvitation", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#a7a1ee4636d1d917e3682490441e8dc0a", null ],
    [ "CreateQuickGame", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#abe2c254dda191a9a65d53006a6927b4f", null ],
    [ "CreateWithInvitationScreen", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#ab59ad2e99f6b63b4cf71ad3bc9b0fb48", null ],
    [ "DeclineInvitation", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#a21c22f516d6644626228541d85ac11fa", null ],
    [ "GetConnectedParticipants", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#a022de50b648aab1c483411ff06e96a6d", null ],
    [ "GetParticipant", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#afd2c2ce2040c764a3370f00789086d89", null ],
    [ "GetSelf", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#a1977bfbd33895593167aa562c021053b", null ],
    [ "IsRoomConnected", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#ade8f785677c1dd00f7535d223ad21445", null ],
    [ "LeaveRoom", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#a6efcef9ff1dee5e61502bca5941c0980", null ],
    [ "SendMessage", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#a385825ef30c37138b8533092bcf1db12", null ],
    [ "SendMessage", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#ab66b9c21ec6cba847a909271682dd776", null ],
    [ "SendMessageToAll", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#a2d654bf3e46ad1aa184afbe1d319e386", null ],
    [ "SendMessageToAll", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html#ad4b4aab97cf3f40c579d07ceed54c06a", null ]
];