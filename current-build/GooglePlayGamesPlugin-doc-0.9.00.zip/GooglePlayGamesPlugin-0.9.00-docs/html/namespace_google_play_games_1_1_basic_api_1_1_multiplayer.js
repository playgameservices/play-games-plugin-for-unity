var namespace_google_play_games_1_1_basic_api_1_1_multiplayer =
[
    [ "Invitation", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_invitation.html", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_invitation" ],
    [ "IRealTimeMultiplayerClient", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client" ],
    [ "ITurnBasedMultiplayerClient", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client" ],
    [ "MatchOutcome", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome" ],
    [ "Participant", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant" ],
    [ "Player", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_player.html", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_player" ],
    [ "RealTimeMultiplayerListener", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_real_time_multiplayer_listener.html", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_real_time_multiplayer_listener" ],
    [ "TurnBasedMatch", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match" ]
];