var class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match =
[
    [ "MatchStatus", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#ad019d74608037955605a698beccd0878", [
      [ "Active", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#ad019d74608037955605a698beccd0878a4d3d769b812b6faa6b76e1a8abaece2d", null ],
      [ "AutoMatching", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#ad019d74608037955605a698beccd0878a858810b7393b09aadbcc0991faac9ff3", null ],
      [ "Cancelled", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#ad019d74608037955605a698beccd0878aa149e85a44aeec9140e92733d9ed694e", null ],
      [ "Complete", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#ad019d74608037955605a698beccd0878aae94f80b3ce82062a5dd7815daa04f9d", null ],
      [ "Expired", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#ad019d74608037955605a698beccd0878a24fe48030f7d3097d5882535b04c3fa8", null ],
      [ "Unknown", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#ad019d74608037955605a698beccd0878a88183b946cc5f0e8c96b2e66e1c74a7e", null ],
      [ "Deleted", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#ad019d74608037955605a698beccd0878a5fe6005bf6e415c950c011fb65f12b8f", null ]
    ] ],
    [ "MatchTurnStatus", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#a29f4035056e7eb496cd274c7ba4832cf", [
      [ "Complete", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#a29f4035056e7eb496cd274c7ba4832cfaae94f80b3ce82062a5dd7815daa04f9d", null ],
      [ "Invited", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#a29f4035056e7eb496cd274c7ba4832cfaaa3443ffdec7410e60018515486e1279", null ],
      [ "MyTurn", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#a29f4035056e7eb496cd274c7ba4832cfa19c43f0eed7b3027e34d77772367b1f3", null ],
      [ "TheirTurn", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#a29f4035056e7eb496cd274c7ba4832cfa3e753025acd177efe9f0dcf56a2270bd", null ],
      [ "Unknown", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#a29f4035056e7eb496cd274c7ba4832cfa88183b946cc5f0e8c96b2e66e1c74a7e", null ]
    ] ],
    [ "GetParticipant", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#ad92ba68d31cb4d61e0ad08c86da339a3", null ],
    [ "ToString", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#aa4163dab99fb68f9defd3642b601ff00", null ],
    [ "AvailableAutomatchSlots", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#af5e2392ef334888c92dd077a59707806", null ],
    [ "CanRematch", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#a63887909bea098a58616875680eac6d7", null ],
    [ "Data", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#ac49d79cbb58afd404bbc6d21cb9ce267", null ],
    [ "MatchId", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#ad0e5262ef576a201883e8802f74a1675", null ],
    [ "Participants", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#ac8d2b5cc82662414c19e079e6a6fc65c", null ],
    [ "PendingParticipant", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#aaf95961de48878c42199c1957ddc2670", null ],
    [ "PendingParticipantId", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#a31f50f7eb7a02c303de269bf1fabac56", null ],
    [ "Self", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#a96c605333ea2407bb7f2415c7be0e282", null ],
    [ "SelfParticipantId", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#ab93685c005a7c40c087f7d2b7cba7d7f", null ],
    [ "Status", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#a44dd823209e05050a08d0f6950f2471e", null ],
    [ "TurnStatus", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#a1b544ef1ac4977a1cb57617abfdacd78", null ],
    [ "Variant", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html#a173286af471b1ae7fcde2c6c3cf28ce1", null ]
];