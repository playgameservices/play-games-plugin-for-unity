var namespace_google_play_games_1_1_basic_api =
[
    [ "Multiplayer", "namespace_google_play_games_1_1_basic_api_1_1_multiplayer.html", "namespace_google_play_games_1_1_basic_api_1_1_multiplayer" ]
];