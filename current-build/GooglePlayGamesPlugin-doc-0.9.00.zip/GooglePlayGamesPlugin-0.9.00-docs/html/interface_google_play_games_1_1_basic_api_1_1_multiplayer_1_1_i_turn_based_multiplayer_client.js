var interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client =
[
    [ "AcceptFromInbox", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#a00d51387287dbd0db96f2283569d2b4a", null ],
    [ "AcceptInvitation", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#a9478284d4c3330baba2655ccdd87186b", null ],
    [ "AcknowledgeFinished", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#abeaf659c96e7c144998d10af1feddedb", null ],
    [ "Cancel", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#a6f749989a1e3c7467e79e3e3b23799dd", null ],
    [ "CreateQuickMatch", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#a8321bf0898ac432f8db286f4681a79f2", null ],
    [ "CreateWithInvitationScreen", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#ad2b3a4a0082ff9d39de0b9d9bab1e568", null ],
    [ "DeclineInvitation", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#a511964a8459b8a13f91d49da3e759a2e", null ],
    [ "Finish", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#a6fed0b76e96a2a56aaae1dba6cbcdf0d", null ],
    [ "GetMaxMatchDataSize", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#af0a03ebffc917ccf350d8d962701b7de", null ],
    [ "Leave", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#a28be0e0704ef2733dd27bb1bc12d3486", null ],
    [ "LeaveDuringTurn", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#a5d040c5da4e889b652a35f1e7e8fdbab", null ],
    [ "RegisterMatchDelegate", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#a4ef9a326e9833136027302d3fc4d0a7a", null ],
    [ "Rematch", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#acea95d30ef8ce82b4c4762e0a3e979fc", null ],
    [ "TakeTurn", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html#a2040384a537d7900fb2114f72ac503b8", null ]
];