var hierarchy =
[
    [ "IAchievement", null, [
      [ "GooglePlayGames.PlayGamesAchievement", "class_google_play_games_1_1_play_games_achievement.html", null ]
    ] ],
    [ "IComparable< Participant >", null, [
      [ "GooglePlayGames.BasicApi.Multiplayer.Participant", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_participant.html", null ]
    ] ],
    [ "ILocalUser", null, [
      [ "GooglePlayGames.PlayGamesLocalUser", "class_google_play_games_1_1_play_games_local_user.html", null ]
    ] ],
    [ "GooglePlayGames.BasicApi.Multiplayer.Invitation", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_invitation.html", null ],
    [ "GooglePlayGames.BasicApi.Multiplayer.IRealTimeMultiplayerClient", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_real_time_multiplayer_client.html", null ],
    [ "IScore", null, [
      [ "GooglePlayGames.PlayGamesScore", "class_google_play_games_1_1_play_games_score.html", null ]
    ] ],
    [ "ISocialPlatform", null, [
      [ "GooglePlayGames.PlayGamesPlatform", "class_google_play_games_1_1_play_games_platform.html", null ]
    ] ],
    [ "GooglePlayGames.BasicApi.Multiplayer.ITurnBasedMultiplayerClient", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_i_turn_based_multiplayer_client.html", null ],
    [ "IUserProfile", null, [
      [ "GooglePlayGames.PlayGamesUserProfile", "class_google_play_games_1_1_play_games_user_profile.html", [
        [ "GooglePlayGames.PlayGamesLocalUser", "class_google_play_games_1_1_play_games_local_user.html", null ]
      ] ]
    ] ],
    [ "GooglePlayGames.BasicApi.Multiplayer.MatchOutcome", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_match_outcome.html", null ],
    [ "GooglePlayGames.BasicApi.Multiplayer.Player", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_player.html", null ],
    [ "GooglePlayGames.BasicApi.Multiplayer.RealTimeMultiplayerListener", "interface_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_real_time_multiplayer_listener.html", null ],
    [ "GooglePlayGames.BasicApi.Multiplayer.TurnBasedMatch", "class_google_play_games_1_1_basic_api_1_1_multiplayer_1_1_turn_based_match.html", null ]
];