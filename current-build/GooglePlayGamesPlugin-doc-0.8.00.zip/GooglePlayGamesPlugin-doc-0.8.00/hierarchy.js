var hierarchy =
[
    [ "IAchievement", null, [
      [ "GooglePlayGames.PlayGamesAchievement", "class_google_play_games_1_1_play_games_achievement.html", null ]
    ] ],
    [ "ILocalUser", null, [
      [ "GooglePlayGames.PlayGamesLocalUser", "class_google_play_games_1_1_play_games_local_user.html", null ]
    ] ],
    [ "IScore", null, [
      [ "GooglePlayGames.PlayGamesScore", "class_google_play_games_1_1_play_games_score.html", null ]
    ] ],
    [ "ISocialPlatform", null, [
      [ "GooglePlayGames.PlayGamesPlatform", "class_google_play_games_1_1_play_games_platform.html", null ]
    ] ],
    [ "IUserProfile", null, [
      [ "GooglePlayGames.PlayGamesUserProfile", "class_google_play_games_1_1_play_games_user_profile.html", [
        [ "GooglePlayGames.PlayGamesLocalUser", "class_google_play_games_1_1_play_games_local_user.html", null ]
      ] ]
    ] ]
];