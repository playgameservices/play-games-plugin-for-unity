var class_google_play_games_1_1_play_games_score =
[
    [ "ReportScore", "class_google_play_games_1_1_play_games_score.html#a2848d7c555e8e78bcf7de42b2b255560", null ],
    [ "date", "class_google_play_games_1_1_play_games_score.html#af911623bfd163f919819beac7610e01a", null ],
    [ "formattedValue", "class_google_play_games_1_1_play_games_score.html#a5d1e7e39d12533da12621368180be33e", null ],
    [ "leaderboardID", "class_google_play_games_1_1_play_games_score.html#aed8e96577d94e857540c0d4eda4c089f", null ],
    [ "rank", "class_google_play_games_1_1_play_games_score.html#a286fc07d22d2abda846421d17597825a", null ],
    [ "userID", "class_google_play_games_1_1_play_games_score.html#ac40ac391c61e9f41e7a20557c3c9963f", null ],
    [ "value", "class_google_play_games_1_1_play_games_score.html#a1044600e530e02458627df717528c107", null ]
];