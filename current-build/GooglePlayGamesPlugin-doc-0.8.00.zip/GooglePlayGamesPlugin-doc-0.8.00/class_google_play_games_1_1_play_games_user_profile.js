var class_google_play_games_1_1_play_games_user_profile =
[
    [ "id", "class_google_play_games_1_1_play_games_user_profile.html#ab820dee129b6a7fe2fc576030a711f18", null ],
    [ "image", "class_google_play_games_1_1_play_games_user_profile.html#ab0ebf0ad4416e4c225dda325eccd8579", null ],
    [ "isFriend", "class_google_play_games_1_1_play_games_user_profile.html#ade393e3e3c3f7c3ece086c1bcc7efd1d", null ],
    [ "state", "class_google_play_games_1_1_play_games_user_profile.html#a5e31dd6d1d8e7b62c469d7ffcfbe5503", null ],
    [ "userName", "class_google_play_games_1_1_play_games_user_profile.html#af55c5392ac08e0387b47927fc4e9b1c3", null ]
];