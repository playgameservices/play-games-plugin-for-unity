var class_google_play_games_1_1_play_games_achievement =
[
    [ "ReportProgress", "class_google_play_games_1_1_play_games_achievement.html#a3006dd50e1b56909041266b071ffc723", null ],
    [ "completed", "class_google_play_games_1_1_play_games_achievement.html#a05bc52e509656cd0d5cb66248e3979e2", null ],
    [ "hidden", "class_google_play_games_1_1_play_games_achievement.html#a6816cfa4e05579f823d01e3b4c8b1095", null ],
    [ "id", "class_google_play_games_1_1_play_games_achievement.html#a5fb2ae47d11f215d58ec88b52b0a6803", null ],
    [ "lastReportedDate", "class_google_play_games_1_1_play_games_achievement.html#a45f5d7e136bded8d2dbe868d4d350a7b", null ],
    [ "percentCompleted", "class_google_play_games_1_1_play_games_achievement.html#a8ba3cbc43f50c35c1106cfee90c7de53", null ]
];