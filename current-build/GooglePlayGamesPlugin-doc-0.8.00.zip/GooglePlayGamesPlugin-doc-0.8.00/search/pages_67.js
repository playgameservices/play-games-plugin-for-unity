var searchData=
[
  ['getting_20started',['Getting Started',['../index.html',1,'']]]
];
