var searchData=
[
  ['incrementachievement',['IncrementAchievement',['../class_google_play_games_1_1_play_games_platform.html#a00118ca719d9b61a9e62154ca9a99899',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['isauthenticated',['IsAuthenticated',['../class_google_play_games_1_1_play_games_platform.html#ae1ba863528f49f91e63a6ca9d7428765',1,'GooglePlayGames::PlayGamesPlatform']]]
];
