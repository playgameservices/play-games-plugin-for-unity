var searchData=
[
  ['reportprogress',['ReportProgress',['../class_google_play_games_1_1_play_games_achievement.html#a3006dd50e1b56909041266b071ffc723',1,'GooglePlayGames.PlayGamesAchievement.ReportProgress()'],['../class_google_play_games_1_1_play_games_platform.html#a64dff72e31b512bdd15169c08852fb6d',1,'GooglePlayGames.PlayGamesPlatform.ReportProgress()']]],
  ['reportscore',['ReportScore',['../class_google_play_games_1_1_play_games_platform.html#a9a51e50e3de344ec7c896d89ca600b1d',1,'GooglePlayGames.PlayGamesPlatform.ReportScore()'],['../class_google_play_games_1_1_play_games_score.html#a2848d7c555e8e78bcf7de42b2b255560',1,'GooglePlayGames.PlayGamesScore.ReportScore()']]]
];
