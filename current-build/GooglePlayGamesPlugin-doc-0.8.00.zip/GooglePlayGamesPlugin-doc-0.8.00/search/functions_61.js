var searchData=
[
  ['activate',['Activate',['../class_google_play_games_1_1_play_games_platform.html#afc68980eb29743625ae7ea74c1e99327',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['addidmapping',['AddIdMapping',['../class_google_play_games_1_1_play_games_platform.html#a5f3b14568fa25fb25f2012549540b835',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['authenticate',['Authenticate',['../class_google_play_games_1_1_play_games_local_user.html#a3f4ec65ac968e23d25dc6c0a64a57745',1,'GooglePlayGames.PlayGamesLocalUser.Authenticate(Action&lt; bool &gt; callback)'],['../class_google_play_games_1_1_play_games_local_user.html#aca511f41133d96ad88d8b10c59cb932c',1,'GooglePlayGames.PlayGamesLocalUser.Authenticate(Action&lt; bool &gt; callback, bool silent)'],['../class_google_play_games_1_1_play_games_platform.html#ad64a1d9469a39947bd125f9c27fe2c58',1,'GooglePlayGames.PlayGamesPlatform.Authenticate(ILocalUser localUser, Action&lt; bool &gt; callback)'],['../class_google_play_games_1_1_play_games_platform.html#a24b16977bc374d29b50b05028496d030',1,'GooglePlayGames.PlayGamesPlatform.Authenticate(ILocalUser unused, Action&lt; bool &gt; callback, bool silent)']]]
];
