var searchData=
[
  ['createachievement',['CreateAchievement',['../class_google_play_games_1_1_play_games_platform.html#a5a3c8132294dfa17c965377292ef3131',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['createleaderboard',['CreateLeaderboard',['../class_google_play_games_1_1_play_games_platform.html#a3f61a6cd7ed0864955972c76d346180d',1,'GooglePlayGames::PlayGamesPlatform']]]
];
