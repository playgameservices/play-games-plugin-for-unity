var searchData=
[
  ['googleplaygames',['GooglePlayGames',['../namespace_google_play_games.html',1,'']]]
];
