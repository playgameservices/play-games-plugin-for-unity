var searchData=
[
  ['getloading',['GetLoading',['../class_google_play_games_1_1_play_games_platform.html#a9555dc92333723ab50047f37687919f6',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['getuserdisplayname',['GetUserDisplayName',['../class_google_play_games_1_1_play_games_platform.html#ad33a89088ff06798207be4a1f808dc6c',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['getuserid',['GetUserId',['../class_google_play_games_1_1_play_games_platform.html#ad2c68f0709dd3e2201e42ffa195b25b3',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['googleplaygames',['GooglePlayGames',['../namespace_google_play_games.html',1,'']]],
  ['getting_20started',['Getting Started',['../index.html',1,'']]]
];
