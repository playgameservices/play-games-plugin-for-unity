var searchData=
[
  ['setcloudcacheencrypter',['SetCloudCacheEncrypter',['../class_google_play_games_1_1_play_games_platform.html#a9dd9ca5f89657e71be15d1b7edcf1d8d',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['setdefaultleaderboardforui',['SetDefaultLeaderboardForUI',['../class_google_play_games_1_1_play_games_platform.html#afc9822ee9fee41d589a7ef79933d6408',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['showachievementsui',['ShowAchievementsUI',['../class_google_play_games_1_1_play_games_platform.html#a2c6db5bcb3d813d12667c83f22eaecbf',1,'GooglePlayGames::PlayGamesPlatform']]],
  ['showleaderboardui',['ShowLeaderboardUI',['../class_google_play_games_1_1_play_games_platform.html#a89d9409cc48dadfa19ba73df80e8db4d',1,'GooglePlayGames.PlayGamesPlatform.ShowLeaderboardUI()'],['../class_google_play_games_1_1_play_games_platform.html#aca62f4cd884bc8918a070dc5b484e23a',1,'GooglePlayGames.PlayGamesPlatform.ShowLeaderboardUI(string lbId)']]],
  ['signout',['SignOut',['../class_google_play_games_1_1_play_games_platform.html#aac525bde71825f39121ef98490be142e',1,'GooglePlayGames::PlayGamesPlatform']]]
];
