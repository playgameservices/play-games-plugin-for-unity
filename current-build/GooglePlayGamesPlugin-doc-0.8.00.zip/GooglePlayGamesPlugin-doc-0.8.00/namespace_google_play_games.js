var namespace_google_play_games =
[
    [ "PlayGamesAchievement", "class_google_play_games_1_1_play_games_achievement.html", "class_google_play_games_1_1_play_games_achievement" ],
    [ "PlayGamesLocalUser", "class_google_play_games_1_1_play_games_local_user.html", "class_google_play_games_1_1_play_games_local_user" ],
    [ "PlayGamesPlatform", "class_google_play_games_1_1_play_games_platform.html", "class_google_play_games_1_1_play_games_platform" ],
    [ "PlayGamesScore", "class_google_play_games_1_1_play_games_score.html", "class_google_play_games_1_1_play_games_score" ],
    [ "PlayGamesUserProfile", "class_google_play_games_1_1_play_games_user_profile.html", "class_google_play_games_1_1_play_games_user_profile" ]
];