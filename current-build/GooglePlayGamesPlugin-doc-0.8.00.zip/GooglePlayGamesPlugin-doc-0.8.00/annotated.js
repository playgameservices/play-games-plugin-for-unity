var annotated =
[
    [ "GooglePlayGames", "namespace_google_play_games.html", "namespace_google_play_games" ]
];